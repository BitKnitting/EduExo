Dear Margaret Johnson,

Thank you for choosing the EduExo.

Please find the handbook, the 3D printable STL files and your invoice in this folder.
The invoice is also your EduExo maker edition license.
We kindly ask you not to share the files publicly or with a larger community. 
Of course, it is perfectly fine to build a second EduExo with a good friend or family member.

You will find several sections dedicated to the maker edition in the handbook to get you started.
We also provide additional information regarding the maker edition on the EduExo website: www.eduexo.com 
In case you run into any problems, please do not hesitate to contact us.

We hope you enjoy your EduExo.

The Beyond Robotics Team